<?php $__env->startSection("container"); ?>
<div class="modal" id="modalDelete" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">¿Reventar el coche?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>¿Reventar el coche?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No lo revientes mejor</button>
        <form id="modalDeleteResourceForm" action="" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn btn-primary" value="Revientaloooooo"/>
        </form>
      </div>
    </div>
  </div>
</div>
<header class="masthead">
  <br>
<h3 style="margin-top: -100px;">Aquí tienes todos los coches </h3>
<br>
<div style=" width:100%; display: flex; align-items: center; justify-content: center; margin-top: 10px;">
<table class="table" style=" color: white;">
   <tr>
      <th>ID</th>
      <th>Nombre</th>
      <th>Color</th>
      <th>Acciones</th>
    </tr>
  <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th>
        <?php echo e($resource["id"]); ?>

      </th>
      <th>
        <?php echo e($resource["name"]); ?>

      </th>
      <th>
        <?php echo e($resource["color"]); ?>

      </th>
      <th>
        <a href="<?php echo e(url('resource/' . $resource['id'] . '/edit')); ?>">Editar</a>
        <br>
        <a href="<?php echo e(url('resource/' . $resource['id'])); ?>">Mostrar</a>
        <br>
        <a href="javascript: void(0);" data-url="<?php echo e(url('resource/' . $resource['id'])); ?>" data-bs-toggle="modal" data-bs-target="#modalDelete">Eliminar</a>
      </th>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
</div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('assets/js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/practicaUno/resources/views/views/index.blade.php ENDPATH**/ ?>