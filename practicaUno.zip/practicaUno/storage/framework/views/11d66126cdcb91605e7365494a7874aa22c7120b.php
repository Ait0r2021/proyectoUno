<?php $__env->startSection("container"); ?>
<header class="masthead">
    
    <h2>Edita tu coche</h2>
    
<form style="margin-top: 70px;" action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("put"); ?>
    <div style=" width:100%; display: flex; align-items: center; justify-content: center; margin-top: 10px;">
    <table>
        <tr>
            <th><input class="text" type="name"  placeholder="<?php echo e($resource['name']); ?>" disabled /></th>
            <th><input class="text" type="name"  placeholder="<?php echo e($resource['color']); ?>" disabled /></th>
        </tr>
        <tr>
            <th><input class="text" type="name" name="name" placeholder="Pon el nuevo nombre" max-length=50 required/></th>
            <th><input class="text" type="name" name="color" placeholder="Pon el nuevo color" max-length=30 required/></th>
        </tr>
    </table>
    </div>
    <br>
    <br>
    <input type="submit" value="Edit"/>
    
</form>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/practicaUno/resources/views/views/edit.blade.php ENDPATH**/ ?>