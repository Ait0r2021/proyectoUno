<?php $__env->startSection("container"); ?>
<header class="masthead">
    <br><br><br>
<h1 style="margin-top: -100px">Introduce los datos del coche a crear</h1>
<br>
<div style=" width:100%; display: flex; align-items: center; justify-content: center; margin-top: 10px;">
<form action="<?php echo e(url('resource')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input class="text" type="name" name="name" placeholder="Pon el nombre" max=50 required />
    <input class="text" type="name" name="color" placeholder="Pon el color" max=30 required />
    <input class="button" class="btn btn-primary" type="submit"/>
</form>
</div>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/practicaUno/resources/views/views/create.blade.php ENDPATH**/ ?>