<?php $__env->startSection("container"); ?>
<header class="masthead">
<h3 style="margin-top: -100px;">Aquí tienes el coche seleccionado </h3>
<br>
<div style=" width:100%; display: flex; align-items: center; justify-content: center; margin-top: 10px;">
<table class="table" style="color: white; position: absolute; margin-top: -10px; margin-left: 50px;">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Color</th>
    </tr>
    <tr>
      <th>
        <?php echo e($resource["id"]); ?>

      </th>
      <th>
        <?php echo e($resource["name"]); ?>

        </th>
      <th>
        <?php echo e($resource["color"]); ?>

        </th>
    </tr>
</table>
</div>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/practicaUno/resources/views/views/show.blade.php ENDPATH**/ ?>