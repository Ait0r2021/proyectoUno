<?php $__env->startSection("container"); ?>
<header class="masthead">
    <br><br><br>
<h1>Introduce los datos del elemento a crear</h1>
<br><br><br>
<form action="<?php echo e(url('resource')); ?>" method="post">
    <input type="name" name="name" placeholder="Pon el nombre" max=50 required/>
    <input class="btn btn-primary" type="submit"/>
</form>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/practicaUno/resources/views/create.blade.php ENDPATH**/ ?>